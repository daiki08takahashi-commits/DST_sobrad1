import { useEffect, useRef, useState } from 'react';
import Topbar from '../components/Topbar.jsx';
import { MoonIcon, SoundOnIcon, SoundOffIcon, ChevronRightIcon } from '../components/icons.jsx';

const SESSION_SECONDS = 2 * 60 * 60; // 2 hours
const MUSIC_VOLUME = 0.45;
const TIDE_PEAK_GAIN = 0.32; // sits a bit under the music layer
const FOAM_PEAK_GAIN = 0.12; // crash/foam accent -- modest relative to the main body
const DISPLAY_TICK_MS = 15000; // recompute remaining time a few times a minute
const FADE_MS = 4000; // gentle fade-out when the timer runs out on its own

// Client-side display preference, same deal as THEME_KEY in api.js -- never
// touches the backend, just remembers the choice across reloads.
const SLEEP_TRACK_KEY = 'sobrad_sleep_track';

// The music layer's selectable tracks. "original" points at the long-
// standing hardcoded file so anyone who never opens the picker gets
// exactly the old behavior.
const SLEEP_TRACKS = [
  { id: 'original', name: 'Original', src: '/audio/insomnia-track.mp3' },
  { id: 'low-tide-drift', name: 'Low Tide Drift', src: '/audio/sleep-sounds/low-tide-drift.mp3' },
  { id: 'drift-in-432', name: 'Drift in 432', src: '/audio/sleep-sounds/drift-in-432.mp3' },
  {
    id: 'weightless-stillness',
    name: 'Weightless Stillness',
    src: '/audio/sleep-sounds/weightless-stillness.mp3',
  },
  {
    id: 'warm-pads-and-felt-piano',
    name: 'Warm Pads and Felt Piano',
    src: '/audio/sleep-sounds/warm-pads-and-felt-piano.mp3',
  },
  {
    id: 'gravitys-gentle-pull',
    name: "Gravity's Gentle Pull",
    src: '/audio/sleep-sounds/gravitys-gentle-pull.mp3',
  },
  {
    id: 'warm-analog-drift',
    name: 'Warm Analog Drift',
    src: '/audio/sleep-sounds/warm-analog-drift.mp3',
  },
  {
    id: 'warm-analog-drift-alt',
    name: 'Warm Analog Drift (Alt)',
    src: '/audio/sleep-sounds/warm-analog-drift-alt.mp3',
  },
];
const DEFAULT_TRACK_ID = SLEEP_TRACKS[0].id;

// Reads back the saved track choice on mount. Falls back to the default
// both when localStorage isn't available (private browsing, etc. -- same
// defensive style as audio.play().catch(...) below) and when the stored id
// doesn't match any known track (e.g. a track was removed after being saved).
function getStoredTrackId() {
  try {
    const stored = window.localStorage.getItem(SLEEP_TRACK_KEY);
    return SLEEP_TRACKS.some((track) => track.id === stored) ? stored : DEFAULT_TRACK_ID;
  } catch {
    return DEFAULT_TRACK_ID;
  }
}

// Builds the tide's main "body" noise buffer. Instead of flat white noise
// (Math.random()*2-1 for every sample), each sample runs through a one-pole
// "leaky integrator" -- a running value that only nudges a little toward
// the new white-noise sample each step -- which biases the result toward
// the low end (pink/brown-ish) instead of being flat across the spectrum.
// That low-end weight is what reads as deep, "watery" rumble rather than
// the airy, hissy texture flat white noise gives, which is what made the
// old tide sound like wind. Output is clamped to [-1, 1] since the gain
// makeup (`* 3.5`) can otherwise push a rare sample past full scale.
function createNoiseBuffer(ctx, seconds = 5) {
  const buffer = ctx.createBuffer(1, ctx.sampleRate * seconds, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let b0 = 0;
  for (let i = 0; i < data.length; i++) {
    const white = Math.random() * 2 - 1;
    b0 = (b0 + 0.02 * white) / 1.02;
    data[i] = Math.max(-1, Math.min(1, b0 * 3.5));
  }
  return buffer;
}

// Builds the shorter, brighter noise buffer for the "foam/crash" transient
// (see scheduleSwellCycle). Only lightly colored -- this layer gets its
// character mainly from the higher-cutoff filter it's routed through in
// start(), not from the buffer itself, so it reads as foam/spray rather
// than another low rumble stacked on top of the main body.
function createFoamNoiseBuffer(ctx, seconds = 2) {
  const buffer = ctx.createBuffer(1, ctx.sampleRate * seconds, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let b0 = 0;
  for (let i = 0; i < data.length; i++) {
    const white = Math.random() * 2 - 1;
    b0 = (b0 + 0.35 * white) / 1.35;
    data[i] = Math.max(-1, Math.min(1, b0 * 1.8));
  }
  return buffer;
}

function formatRemaining(totalSeconds) {
  const totalMinutes = Math.floor(totalSeconds / 60);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours > 0) return `${hours}h ${minutes}m remaining`;
  if (minutes > 0) return `${minutes}m remaining`;
  return 'Less than a minute remaining';
}

export default function Insomnia() {
  const [active, setActive] = useState(false);
  const [muted, setMuted] = useState(false);
  const [tideOn, setTideOn] = useState(true);
  const [remaining, setRemaining] = useState(SESSION_SECONDS);
  const [selectedTrackId, setSelectedTrackId] = useState(getStoredTrackId);
  const [trackMenuOpen, setTrackMenuOpen] = useState(false);

  const selectedTrack =
    SLEEP_TRACKS.find((track) => track.id === selectedTrackId) ?? SLEEP_TRACKS[0];

  const trackMenuRef = useRef(null);
  const audioRef = useRef(null);
  const activeRef = useRef(false);
  const mutedRef = useRef(false);
  const tideOnRef = useRef(true);

  const endAtRef = useRef(null);
  const displayTimerRef = useRef(null);
  const swellTimeoutRef = useRef(null);

  // Web Audio graph for the synthesized "tide" layer: two noise sources --
  // the main watery body, and a brief foam/crash accent -- each through
  // their own filter and gain envelope, mixed together into a shared
  // on/off gain (tide toggle) -> mute gain (session mute) -> destination.
  const audioCtxRef = useRef(null);
  const tideSourceRef = useRef(null);
  const swellGainRef = useRef(null);
  const foamSourceRef = useRef(null);
  const foamGainRef = useRef(null);
  const onOffGainRef = useRef(null);
  const tideMuteGainRef = useRef(null);

  // Schedules one "wave" of the tide layer. A real wave builds toward its
  // break relatively fast and then recedes/hisses out much more slowly --
  // not a smooth, symmetric swell -- so the rise here (2-4s) is roughly a
  // quarter of the fall (the remainder of the 10-14s cycle). The foam/crash
  // layer is gated open right at the top of that rise (a fast ~0.3-0.6s
  // attack) so the crash transient lands exactly as the main body peaks,
  // then fades over ~1-2s, mirroring how a wave's foam trails its crest.
  // Depth/timing are randomized per cycle (as before), and it reschedules
  // itself for as long as the session stays active.
  function scheduleSwellCycle() {
    if (!activeRef.current) return;
    const ctx = audioCtxRef.current;
    const gainNode = swellGainRef.current;
    const foamGain = foamGainRef.current;
    if (!ctx || !gainNode) return;

    const now = ctx.currentTime;
    const cycleSeconds = 10 + Math.random() * 4; // 10-14s per wave
    const riseSeconds = 2 + Math.random() * 2; // 2-4s fast build toward the crash
    const peak = TIDE_PEAK_GAIN * (0.55 + Math.random() * 0.45);
    const trough = TIDE_PEAK_GAIN * (0.05 + Math.random() * 0.08);

    gainNode.gain.cancelScheduledValues(now);
    gainNode.gain.setValueAtTime(gainNode.gain.value, now);
    gainNode.gain.linearRampToValueAtTime(peak, now + riseSeconds);
    gainNode.gain.linearRampToValueAtTime(trough, now + cycleSeconds); // slow ~6-10s recede/hiss-out

    if (foamGain) {
      const foamPeak = FOAM_PEAK_GAIN * (0.6 + Math.random() * 0.4);
      const attackSeconds = 0.3 + Math.random() * 0.3; // 0.3-0.6s fast attack
      const releaseSeconds = 1 + Math.random(); // 1-2s quick fade
      const attackStart = Math.max(now, now + riseSeconds - attackSeconds);
      foamGain.gain.cancelScheduledValues(now);
      foamGain.gain.setValueAtTime(0.0001, now);
      foamGain.gain.setValueAtTime(0.0001, attackStart);
      foamGain.gain.linearRampToValueAtTime(foamPeak, now + riseSeconds);
      foamGain.gain.linearRampToValueAtTime(0.0001, now + riseSeconds + releaseSeconds);
    }

    swellTimeoutRef.current = setTimeout(scheduleSwellCycle, cycleSeconds * 1000);
  }

  function tickDisplay() {
    const endAt = endAtRef.current;
    if (endAt == null) return;
    const remainingSeconds = Math.max(0, Math.round((endAt - Date.now()) / 1000));
    setRemaining(remainingSeconds);
    if (remainingSeconds <= 0) {
      stopWithFade();
    }
  }

  // Stops and tears down both audio layers: pauses/rewinds the <audio>
  // element and stops + closes the tide's AudioContext graph, mirroring the
  // cleanup pattern in Breathing.jsx. Deliberately touches only refs (not
  // React state) so it's also safe to call from the unmount cleanup below.
  function teardownAudio() {
    clearInterval(displayTimerRef.current);
    displayTimerRef.current = null;
    clearTimeout(swellTimeoutRef.current);
    swellTimeoutRef.current = null;

    const audio = audioRef.current;
    if (audio) {
      audio.pause();
      audio.currentTime = 0;
      audio.volume = MUSIC_VOLUME;
    }

    const source = tideSourceRef.current;
    if (source) {
      try {
        source.stop();
      } catch {
        // already stopped -- nothing to do
      }
      try {
        source.disconnect();
      } catch {
        // already disconnected -- nothing to do
      }
    }
    const foamSource = foamSourceRef.current;
    if (foamSource) {
      try {
        foamSource.stop();
      } catch {
        // already stopped -- nothing to do
      }
      try {
        foamSource.disconnect();
      } catch {
        // already disconnected -- nothing to do
      }
    }
    tideSourceRef.current = null;
    swellGainRef.current = null;
    foamSourceRef.current = null;
    foamGainRef.current = null;
    onOffGainRef.current = null;
    tideMuteGainRef.current = null;

    const ctx = audioCtxRef.current;
    if (ctx && ctx.state !== 'closed') {
      ctx.close().catch(() => {});
    }
    audioCtxRef.current = null;
    activeRef.current = false;
  }

  function hardStop() {
    teardownAudio();
    setActive(false);
    endAtRef.current = null;
    setRemaining(SESSION_SECONDS);
  }

  // Used when the 2-hour timer runs out on its own: a short fade instead of
  // a hard cut, then the same cleanup as a manual stop.
  function stopWithFade() {
    const ctx = audioCtxRef.current;
    const muteGain = tideMuteGainRef.current;
    if (ctx && muteGain) {
      const now = ctx.currentTime;
      muteGain.gain.cancelScheduledValues(now);
      muteGain.gain.setValueAtTime(muteGain.gain.value, now);
      muteGain.gain.linearRampToValueAtTime(0, now + FADE_MS / 1000);
    }
    const audio = audioRef.current;
    if (audio) {
      const startVolume = audio.volume;
      const steps = 10;
      let step = 0;
      const fadeInterval = setInterval(() => {
        step += 1;
        audio.volume = Math.max(0, startVolume * (1 - step / steps));
        if (step >= steps) clearInterval(fadeInterval);
      }, FADE_MS / steps);
    }
    setTimeout(hardStop, FADE_MS + 50);
  }

  function start() {
    let ctx = audioCtxRef.current;
    if (!ctx || ctx.state === 'closed') {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      audioCtxRef.current = ctx;
    } else if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const source = ctx.createBufferSource();
    source.buffer = createNoiseBuffer(ctx);
    source.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 400; // warm, low "body" -- well under the old 750Hz, which read as windy hiss

    const swellGain = ctx.createGain();
    swellGain.gain.value = 0.05;

    // Foam/crash layer: a second, shorter noise buffer through a brighter
    // bandpass filter, silent most of the time and briefly gated open by
    // scheduleSwellCycle right as the main swell peaks -- the sound of a
    // wave breaking, layered under the main body rather than replacing it.
    const foamSource = ctx.createBufferSource();
    foamSource.buffer = createFoamNoiseBuffer(ctx);
    foamSource.loop = true;

    const foamFilter = ctx.createBiquadFilter();
    foamFilter.type = 'bandpass';
    foamFilter.frequency.value = 2400;
    foamFilter.Q.value = 0.8;

    const foamGain = ctx.createGain();
    foamGain.gain.value = 0.0001;

    const onOffGain = ctx.createGain();
    onOffGain.gain.value = tideOnRef.current ? 1 : 0;

    const muteGain = ctx.createGain();
    muteGain.gain.value = mutedRef.current ? 0 : 1;

    source.connect(filter);
    filter.connect(swellGain);
    swellGain.connect(onOffGain);

    foamSource.connect(foamFilter);
    foamFilter.connect(foamGain);
    foamGain.connect(onOffGain);

    onOffGain.connect(muteGain);
    muteGain.connect(ctx.destination);
    source.start();
    foamSource.start();

    tideSourceRef.current = source;
    swellGainRef.current = swellGain;
    foamSourceRef.current = foamSource;
    foamGainRef.current = foamGain;
    onOffGainRef.current = onOffGain;
    tideMuteGainRef.current = muteGain;

    activeRef.current = true;
    setActive(true);
    // Belt-and-suspenders: the trigger is disabled while active (see render
    // below) so this shouldn't normally be reachable with the panel open,
    // but close it anyway rather than leaving stale open state around.
    setTrackMenuOpen(false);

    // Started inside the same click handler as the tide graph above, so
    // this still counts as a user gesture and autoplay-with-sound isn't
    // blocked.
    const audio = audioRef.current;
    if (audio) {
      audio.volume = MUSIC_VOLUME;
      audio.muted = mutedRef.current;
      audio.currentTime = 0;
      audio.play().catch(() => {
        // Best-effort: the tide layer still plays even if this is blocked.
      });
    }

    endAtRef.current = Date.now() + SESSION_SECONDS * 1000;
    setRemaining(SESSION_SECONDS);
    scheduleSwellCycle();
    displayTimerRef.current = setInterval(tickDisplay, DISPLAY_TICK_MS);
  }

  function stop() {
    hardStop();
  }

  function toggleMute() {
    setMuted((prev) => {
      const next = !prev;
      mutedRef.current = next;
      if (audioRef.current) audioRef.current.muted = next;
      const ctx = audioCtxRef.current;
      const muteGain = tideMuteGainRef.current;
      if (ctx && muteGain) {
        const now = ctx.currentTime;
        muteGain.gain.cancelScheduledValues(now);
        muteGain.gain.setTargetAtTime(next ? 0 : 1, now, 0.05);
      }
      return next;
    });
  }

  function toggleTide() {
    setTideOn((prev) => {
      const next = !prev;
      tideOnRef.current = next;
      const ctx = audioCtxRef.current;
      const onOffGain = onOffGainRef.current;
      if (ctx && onOffGain) {
        const now = ctx.currentTime;
        onOffGain.gain.cancelScheduledValues(now);
        onOffGain.gain.setTargetAtTime(next ? 1 : 0, now, 0.15);
      }
      return next;
    });
  }

  // Switches the music-layer track. The picker UI already disables itself
  // while `active` (see render below) so the user has to Stop first -- swapping
  // the <audio> element's `src` out from under a playing session would need
  // its own load/seek handling that isn't worth adding for what's otherwise a
  // simple preference, so this just guards the same thing at the state level.
  function selectTrack(id) {
    if (activeRef.current) return;
    setSelectedTrackId(id);
    setTrackMenuOpen(false);
    try {
      window.localStorage.setItem(SLEEP_TRACK_KEY, id);
    } catch {
      // localStorage unavailable -- the choice just won't persist, same
      // fallback as getStoredTrackId above.
    }
  }

  // Same open-while-mounted Escape/outside-click-close mechanism as
  // CompanionRow's kebab menu in Chat.jsx (search `chat-list-row-menu`):
  // only listens while the panel is open, ref-scoped to the whole picker
  // so a click on the trigger itself doesn't immediately reopen after
  // closing, cleans up both listeners on close/unmount.
  useEffect(() => {
    if (!trackMenuOpen) return undefined;
    function handleKeyDown(e) {
      if (e.key === 'Escape') setTrackMenuOpen(false);
    }
    function handlePointerDown(e) {
      if (trackMenuRef.current && !trackMenuRef.current.contains(e.target)) {
        setTrackMenuOpen(false);
      }
    }
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('mousedown', handlePointerDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('mousedown', handlePointerDown);
    };
  }, [trackMenuOpen]);

  // Leaving the screen mid-session stops both layers, same as Breathing.jsx.
  useEffect(() => {
    return () => {
      teardownAudio();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <Topbar title="Sleep" />
      <div className="screen-inner screen-center">
        <div className="insomnia-card">
          <button
            type="button"
            className="mute-toggle"
            onClick={toggleMute}
            aria-label={muted ? 'Unmute sound' : 'Mute sound'}
            aria-pressed={muted}
          >
            {muted ? <SoundOffIcon /> : <SoundOnIcon />}
          </button>

          <div className={`insomnia-moon${active ? ' active' : ''}`} aria-hidden="true">
            <MoonIcon />
          </div>

          <p className="insomnia-status">
            {active ? formatRemaining(remaining) : 'A calm, looping sound for up to two hours.'}
          </p>

          <button className="btn btn-primary insomnia-toggle" onClick={active ? stop : start}>
            {active ? 'Stop' : 'Start'}
          </button>

          <button
            type="button"
            className={`insomnia-tide-toggle${tideOn ? ' on' : ''}`}
            onClick={toggleTide}
            aria-pressed={tideOn}
          >
            <span className="insomnia-tide-dot" aria-hidden="true" />
            Tide sounds {tideOn ? 'on' : 'off'}
          </button>

          {/* Collapsed "pull down" picker, mirroring CompanionRow's kebab
              menu in Chat.jsx (search `chat-list-row-menu`): a single
              trigger button + ref'd wrapper, toggled open state, and a
              floating panel of the same options that used to render as an
              always-visible vertical list. Locked shut while a session is
              `active` (disabled trigger) so Stop is still required before
              changing tracks -- see selectTrack()'s own guard above. */}
          <div className="sleep-track-picker" ref={trackMenuRef}>
            <button
              type="button"
              className={`sleep-track-trigger${trackMenuOpen ? ' open' : ''}`}
              onClick={() => setTrackMenuOpen((prev) => !prev)}
              disabled={active}
              aria-haspopup="listbox"
              aria-expanded={trackMenuOpen}
            >
              <span>Sound: {selectedTrack.name}</span>
              <ChevronRightIcon className="sleep-track-trigger-chevron" aria-hidden="true" />
            </button>
            {trackMenuOpen && !active && (
              <div className="sleep-track-panel" role="listbox">
                {SLEEP_TRACKS.map((track) => (
                  <button
                    key={track.id}
                    type="button"
                    className={`sleep-track-option${track.id === selectedTrackId ? ' selected' : ''}`}
                    onClick={() => selectTrack(track.id)}
                    role="option"
                    aria-selected={track.id === selectedTrackId}
                  >
                    <span>{track.name}</span>
                    {track.id === selectedTrackId ? (
                      <span className="sleep-track-check" aria-hidden="true">
                        ✓
                      </span>
                    ) : null}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <p className="breathe-note">
          Let the sound settle in the background while you drift off. It fades out on its own
          after two hours, or you can stop it any time.
        </p>

        <audio ref={audioRef} src={selectedTrack.src} loop preload="none" />
      </div>
    </>
  );
}
